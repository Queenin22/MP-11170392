package com.intan.car

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val imageView = findViewById<ImageView>(R.id.imageView)
        val imgResId = R.drawable.mobil1
        var resId = imgResId
        imageView.setImageResource(imgResId)

        var i: Int = 1

        val button = findViewById<Button>(R.id.button2)
        button?.setOnClickListener {
            resId = if (i == 1) {
                i = 2
                R.drawable.mobil1
            } else {
                i = 1
                R.drawable.mobil2
            }

            imageView.setImageResource(resId)

        }

    }
    }


